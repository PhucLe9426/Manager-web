<?php
/**
 * Plugin Name: SiteOps Security Agent v1.5
 * Description: Kết nối với SiteOps để kiểm tra tính toàn vẹn và dấu hiệu rủi ro của plugin.
 * Version: 1.5.0
 * Requires at least: 5.6
 * Requires PHP: 7.4
 * Author: SiteOps
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SITEOPS_SECURITY_V15_VERSION', '1.5.0' );

add_action(
    'rest_api_init',
    static function () {
        register_rest_field(
            'post',
            'siteops_rank_math',
            array(
                'get_callback' => static function ( $post ) {
                    $post_id = isset( $post['id'] ) ? (int) $post['id'] : 0;
                    if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
                        return null;
                    }

                    $score = get_post_meta( $post_id, 'rank_math_seo_score', true );
                    return array(
                        'score'        => is_numeric( $score ) ? (int) $score : null,
                        'title'        => (string) get_post_meta( $post_id, 'rank_math_title', true ),
                        'description'  => (string) get_post_meta( $post_id, 'rank_math_description', true ),
                        'focusKeyword' => (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true ),
                    );
                },
                'schema' => array(
                    'description' => 'Dữ liệu SEO chỉ đọc từ Rank Math dành cho SiteOps.',
                    'type'        => array( 'object', 'null' ),
                    'context'     => array( 'edit' ),
                    'readonly'    => true,
                ),
            )
        );

        register_rest_route(
            'siteops-security/v5',
            '/security/plugins',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => 'siteops_security_v15_scan_plugins',
                'permission_callback' => static function () {
                    return current_user_can( 'manage_options' );
                },
            )
        );
    }
);

/*
 * Một số hosting làm rỗng response của namespace REST tùy chỉnh. Khi SiteOps
 * gửi cờ riêng tới endpoint plugin lõi, trả kết quả quét qua chính endpoint
 * wp/v2 đã được hosting cho phép.
 */
add_filter(
    'rest_pre_dispatch',
    static function ( $result, $server, $request ) {
        if ( '/wp/v2/plugins' !== $request->get_route() || '1' !== (string) $request->get_param( 'siteops_security_scan_v15' ) ) {
            return $result;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            return new WP_Error( 'siteops_forbidden', 'Tài khoản không có quyền quản trị.', array( 'status' => 403 ) );
        }

        return siteops_security_v15_scan_plugins();
    },
    10,
    3
);

/**
 * Quét ở chế độ chỉ đọc. Endpoint không trả nội dung mã nguồn.
 */
function siteops_security_v15_scan_plugins() {
    if ( ! function_exists( 'get_plugins' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $results = array();
    foreach ( get_plugins() as $plugin_file => $plugin_data ) {
        try {
            $results[] = siteops_security_v15_scan_plugin( $plugin_file, $plugin_data );
        } catch ( Throwable $error ) {
            $directory = dirname( $plugin_file );
            $results[] = array(
                'plugin'        => sanitize_text_field( $plugin_file ),
                'slug'          => sanitize_key( '.' === $directory ? basename( $plugin_file, '.php' ) : $directory ),
                'name'          => sanitize_text_field( $plugin_data['Name'] ?? $plugin_file ),
                'version'       => sanitize_text_field( $plugin_data['Version'] ?? '' ),
                'active'        => is_plugin_active( $plugin_file ),
                'source'        => 'scan-error',
                'licenseStatus' => 'unknown',
                'integrity'     => 'unknown',
                'risk'          => 'unknown',
                'findings'      => array( 'Không thể đọc plugin này: ' . sanitize_text_field( get_class( $error ) ) ),
                'changedFiles'  => array(),
                'codeSignals'   => array(),
            );
        }
    }

    $payload = array(
        'agentVersion'     => SITEOPS_SECURITY_V15_VERSION,
        'wordpressVersion' => get_bloginfo( 'version' ),
        'phpVersion'       => PHP_VERSION,
        'scannedAt'        => current_time( 'c', true ),
        'plugins'          => $results,
        'summary'          => array(
            'total'    => count( $results ),
            'verified' => count( array_filter( $results, static fn( $item ) => 'verified' === $item['integrity'] ) ),
            'modified' => count( array_filter( $results, static fn( $item ) => 'modified' === $item['integrity'] ) ),
            'warning'  => count( array_filter( $results, static fn( $item ) => in_array( $item['risk'], array( 'medium', 'high' ), true ) ) ),
            'unknown'  => count( array_filter( $results, static fn( $item ) => 'unknown' === $item['integrity'] ) ),
        ),
    );

    $json = wp_json_encode( siteops_security_v15_json_safe( $payload ), JSON_INVALID_UTF8_SUBSTITUTE );
    if ( false === $json ) {
        return new WP_Error( 'siteops_json_error', 'Không thể mã hóa kết quả quét.', array( 'status' => 500 ) );
    }

    return rest_ensure_response(
        array(
            'siteopsPayload' => base64_encode( $json ),
        )
    );
}

/**
 * Loại bỏ byte UTF-8 lỗi trong metadata/tên file plugin để WordPress luôn mã hóa được JSON.
 */
function siteops_security_v15_json_safe( $value ) {
    if ( is_array( $value ) ) {
        $safe = array();
        foreach ( $value as $key => $item ) {
            $safe_key          = is_string( $key ) ? wp_check_invalid_utf8( $key, true ) : $key;
            $safe[ $safe_key ] = siteops_security_v15_json_safe( $item );
        }
        return $safe;
    }

    if ( is_string( $value ) ) {
        return wp_check_invalid_utf8( $value, true );
    }

    if ( is_float( $value ) && ( is_nan( $value ) || is_infinite( $value ) ) ) {
        return null;
    }

    return $value;
}

function siteops_security_v15_scan_plugin( $plugin_file, $plugin_data ) {
    $version    = isset( $plugin_data['Version'] ) ? (string) $plugin_data['Version'] : '';
    $directory  = dirname( $plugin_file );
    $slug       = '.' === $directory ? sanitize_key( basename( $plugin_file, '.php' ) ) : sanitize_key( $directory );
    $plugin_dir = '.' === $directory ? WP_PLUGIN_DIR : WP_PLUGIN_DIR . '/' . $directory;
    $files      = '.' === $directory
        ? array( basename( $plugin_file ) => WP_PLUGIN_DIR . '/' . $plugin_file )
        : siteops_security_v15_list_files( $plugin_dir );
    $checksums  = siteops_security_v15_get_checksums( $slug, $version );
    $findings   = array();
    $modified   = array();
    $missing    = array();
    $unexpected = array();

    if ( is_array( $checksums ) ) {
        foreach ( $checksums as $relative => $expected_data ) {
            $full_path = trailingslashit( $plugin_dir ) . ltrim( $relative, '/' );
            if ( ! is_file( $full_path ) ) {
                $missing[] = $relative;
                continue;
            }

            $expected  = is_array( $expected_data ) ? ( $expected_data['sha256'] ?? $expected_data['md5'] ?? '' ) : $expected_data;
            $algorithm = 64 === strlen( $expected ) ? 'sha256' : 'md5';
            if ( $expected && ! hash_equals( strtolower( $expected ), strtolower( hash_file( $algorithm, $full_path ) ) ) ) {
                $modified[] = $relative;
            }
        }

        foreach ( $files as $relative => $full_path ) {
            if ( ! isset( $checksums[ $relative ] ) && 'php' === strtolower( pathinfo( $relative, PATHINFO_EXTENSION ) ) ) {
                $unexpected[] = $relative;
            }
        }
    }

    $code_signals = 'siteops-agent-v15-rankmath' === $slug ? array() : siteops_security_v15_scan_code_signals( $files );
    if ( $modified ) {
        $findings[] = count( $modified ) . ' file không khớp checksum chính thức.';
    }
    if ( $missing ) {
        $findings[] = count( $missing ) . ' file chính thức bị thiếu.';
    }
    if ( $unexpected ) {
        $findings[] = count( $unexpected ) . ' file PHP không có trong bản phát hành chính thức.';
    }
    if ( $code_signals ) {
        $findings[] = count( $code_signals ) . ' dấu hiệu mã cần kiểm tra thủ công.';
    }

    $integrity = null === $checksums ? 'unknown' : ( $modified || $missing || $unexpected ? 'modified' : 'verified' );
    $risk      = 'low';
    if ( 'modified' === $integrity || siteops_security_v15_has_high_signal( $code_signals ) ) {
        $risk = 'high';
    } elseif ( $code_signals ) {
        $risk = 'medium';
    } elseif ( 'unknown' === $integrity ) {
        $risk = 'unknown';
    }

    return array(
        'plugin'        => $plugin_file,
        'slug'          => $slug,
        'name'          => wp_strip_all_tags( $plugin_data['Name'] ?? $plugin_file ),
        'version'       => $version,
        'active'        => is_plugin_active( $plugin_file ),
        'source'        => null === $checksums ? 'third-party-or-custom' : 'wordpress.org',
        'licenseStatus' => null === $checksums ? 'unknown' : 'not-required',
        'integrity'     => $integrity,
        'risk'          => $risk,
        'findings'      => $findings,
        'changedFiles'  => array_slice( array_values( array_unique( array_merge( $modified, $missing, $unexpected ) ) ), 0, 30 ),
        'codeSignals'   => array_slice( $code_signals, 0, 30 ),
    );
}

function siteops_security_v15_get_checksums( $slug, $version ) {
    if ( ! $slug || ! $version ) {
        return null;
    }

    $cache_key = 'siteops_checksum_' . md5( $slug . ':' . $version );
    $cached    = get_transient( $cache_key );
    if ( is_array( $cached ) ) {
        return $cached;
    }

    $url      = sprintf( 'https://downloads.wordpress.org/plugin-checksums/%s/%s.json', rawurlencode( $slug ), rawurlencode( $version ) );
    $response = wp_safe_remote_get( $url, array( 'timeout' => 15, 'redirection' => 2 ) );
    if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
        return null;
    }

    $payload = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( isset( $payload['files'] ) && is_array( $payload['files'] ) ) {
        set_transient( $cache_key, $payload['files'], 12 * HOUR_IN_SECONDS );
        return $payload['files'];
    }
    return null;
}

function siteops_security_v15_list_files( $root ) {
    $files = array();
    if ( ! is_dir( $root ) ) {
        return $files;
    }

    try {
        $iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
        foreach ( $iterator as $file ) {
            if ( ! $file->isFile() || count( $files ) >= 5000 ) {
                continue;
            }
            $full_path          = wp_normalize_path( $file->getPathname() );
            $relative           = ltrim( substr( $full_path, strlen( wp_normalize_path( trailingslashit( $root ) ) ) ), '/' );
            $files[ $relative ] = $full_path;
        }
    } catch ( UnexpectedValueException $error ) {
        return $files;
    }

    return $files;
}

function siteops_security_v15_scan_code_signals( $files ) {
    $patterns = array(
        'obfuscated-eval' => array( 'level' => 'high', 'regex' => '/eval\s*\(\s*base64_decode\s*\(/i' ),
        'encoded-payload' => array( 'level' => 'medium', 'regex' => '/(?:gzinflate|gzuncompress)\s*\(\s*base64_decode\s*\(/i' ),
        'request-exec'    => array( 'level' => 'high', 'regex' => '/(?:eval|assert|system|passthru|shell_exec)\s*\(\s*\$_(?:GET|POST|REQUEST|COOKIE)/i' ),
        'license-bypass'  => array( 'level' => 'medium', 'regex' => '/(?:bypass|disable|skip)[_-]?(?:license|activation)|nulled|cracked/i' ),
    );
    $signals = array();

    foreach ( $files as $relative => $full_path ) {
        if ( 'php' !== strtolower( pathinfo( $relative, PATHINFO_EXTENSION ) ) || filesize( $full_path ) > 2 * MB_IN_BYTES ) {
            continue;
        }
        $contents = file_get_contents( $full_path );
        if ( false === $contents ) {
            continue;
        }
        foreach ( $patterns as $type => $pattern ) {
            if ( preg_match( $pattern['regex'], $contents ) ) {
                $signals[] = array( 'type' => $type, 'level' => $pattern['level'], 'file' => $relative );
            }
        }
    }

    return $signals;
}

function siteops_security_v15_has_high_signal( $signals ) {
    foreach ( $signals as $signal ) {
        if ( 'high' === $signal['level'] ) {
            return true;
        }
    }
    return false;
}
